#!/usr/bin/env python3
"""Clean up Qdrant database."""

from qdrant_client import QdrantClient

client = QdrantClient(url="http://localhost:6333")

# List all collections
collections = client.get_collections().collections

if collections:
    for collection in collections:
        print(f"Deleting collection: {collection.name}")
        client.delete_collection(collection.name)
    print("✅ All collections deleted")
else:
    print("No collections found")