from typing import Optional, Dict, List
import os
from services.document_service import LlamaDocumentService
from services.chunking_service import ChunkingService
from services.embedding_service import EmbeddingService
from services.vector_store_service import VectorStoreService
from models.document import Document, DocumentUploadRequest, DocumentSearchRequest, DocumentSearchResponse
from config.settings import settings


class RAGPipelineService:
    """Service that orchestrates the complete RAG pipeline for document ingestion."""

    def __init__(self):
        """Initialize all required services."""
        self.document_parser = LlamaDocumentService()
        self.chunking_service = ChunkingService()
        self.embedding_service = EmbeddingService()
        self.vector_store = VectorStoreService()

    async def initialize(self):
        """Initialize the vector store collection."""
        await self.vector_store.create_collection(recreate=False)

    async def process_document(
        self,
        file_path: str,
        org_id: str,
        doc_name: str,
        metadata: Optional[Dict] = None
    ) -> Document:
        """Process a document through the complete RAG pipeline.

        Args:
            file_path: Path to the document file
            org_id: Organization ID for multi-tenancy
            doc_name: Document name (unique per org)
            metadata: Additional metadata to store

        Returns:
            Document object with processed chunks

        Raises:
            FileNotFoundError: If file doesn't exist
            RuntimeError: If any processing step fails
        """
        try:
            print(f"📄 Processing document: {doc_name}")

            # Step 1: Parse the document
            print("  1️⃣ Parsing document...")
            text = await self.document_parser.parse(file_path)
            print(f"     ✓ Extracted {len(text)} characters")

            # Step 2: Chunk the text
            print("  2️⃣ Chunking text...")
            chunks = self.chunking_service.chunk_text(
                text,
                chunk_size=settings.chunk_size,
                overlap=settings.chunk_overlap
            )
            print(f"     ✓ Created {len(chunks)} chunks")

            # Step 3: Generate embeddings
            print("  3️⃣ Generating embeddings...")
            chunk_texts = [chunk["text"] for chunk in chunks]
            embeddings = await self.embedding_service.create_embeddings(chunk_texts)
            print(f"     ✓ Generated {len(embeddings)} embeddings")

            # Create Document object with auto-generated doc_id
            document = Document(
                doc_name=doc_name,
                org_id=org_id,
                file_type=os.path.splitext(file_path)[1].lstrip('.'),
                metadata=metadata
            )

            # Step 4: Store in vector database
            print("  4️⃣ Storing in vector database...")
            point_ids = await self.vector_store.store_embeddings(
                chunks=chunks,
                embeddings=embeddings,
                org_id=org_id,
                doc_id=document.doc_id,
                doc_name=doc_name,
                metadata=metadata
            )
            print(f"     ✓ Stored {len(point_ids)} vectors")

            print(f"✅ Successfully processed document: {doc_name} (ID: {document.doc_id})")
            return document

        except FileNotFoundError as e:
            print(f"❌ File not found: {e}")
            raise
        except Exception as e:
            print(f"❌ Processing failed: {e}")
            raise RuntimeError(f"Failed to process document: {e}")

    async def search(
        self,
        query: str,
        org_id: Optional[str] = None,
        doc_id: Optional[str] = None,
        doc_name: Optional[str] = None,
        limit: int = 10,
        score_threshold: Optional[float] = None
    ) -> DocumentSearchResponse:
        """Search for relevant document chunks.

        Args:
            query: Search query text
            org_id: Filter by organization ID
            doc_id: Filter by document ID
            doc_name: Filter by document name
            limit: Maximum number of results
            score_threshold: Minimum similarity score

        Returns:
            Search response with results
        """
        try:
            # Generate query embedding
            query_embedding = await self.embedding_service.create_single_embedding(query)

            # Search in vector store
            results = await self.vector_store.search(
                query_embedding=query_embedding,
                org_id=org_id,
                doc_id=doc_id,
                doc_name=doc_name,
                limit=limit,
                score_threshold=score_threshold
            )

            return DocumentSearchResponse(
                query=query,
                results=results,
                total_results=len(results)
            )

        except Exception as e:
            raise RuntimeError(f"Search failed: {e}")

    async def delete_document(self, org_id: str, doc_name: str) -> bool:
        """Delete a document from the vector store.

        Args:
            org_id: Organization ID
            doc_name: Document name to delete

        Returns:
            True if deletion was successful
        """
        try:
            await self.vector_store.delete_document(org_id, doc_name)
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to delete document: {e}")

    async def process_upload_request(self, request: DocumentUploadRequest) -> Document:
        """Process a document upload request.

        Args:
            request: Document upload request with file path and metadata

        Returns:
            Processed document
        """
        return await self.process_document(
            file_path=request.file_path,
            org_id=request.org_id,
            doc_name=request.doc_name,
            metadata=request.metadata
        )

    async def process_search_request(self, request: DocumentSearchRequest) -> DocumentSearchResponse:
        """Process a document search request.

        Args:
            request: Search request with query and filters

        Returns:
            Search response
        """
        return await self.search(
            query=request.query,
            org_id=request.org_id,
            doc_id=request.doc_id,
            doc_name=request.doc_name,
            limit=request.limit,
            score_threshold=request.score_threshold
        )