from abc import ABC, abstractmethod
from llama_parse import LlamaParse
from config.settings import settings
import os


class DocumentParser(ABC):
    """Abstract base class for document parsers."""

    @abstractmethod
    def parse(self, file_path: str) -> str:
        """Parse a document and return its text content."""
        pass


class LlamaDocumentService(DocumentParser):
    """Document parser service using LlamaParse."""

    def __init__(self):
        self.parser = LlamaParse(
            api_key=settings.llama_parse_api_key,
            result_type="markdown",
            num_workers=4,
            verbose=True,
            language="en"
        )

    async def parse(self, file_path: str) -> str:
        """Parse a PDF document using LlamaParse.

        Args:
            file_path: Path to the PDF file

        Returns:
            Extracted text content as markdown

        Raises:
            FileNotFoundError: If the file doesn't exist
            RuntimeError: If parsing fails
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        try:
            print("     → Using LlamaParse...")
            documents = await self.parser.aload_data(file_path)
            complete_text = ""
            for document in documents:
                complete_text += "\n" + document.text
            return complete_text
        except Exception as e:
            print(f"     ⚠️  LlamaParse failed: {e}. Falling back to local pypdf parser...")
            try:
                from pypdf import PdfReader
                reader = PdfReader(file_path)
                text = ""
                for page in reader.pages:
                    extracted_text = page.extract_text()
                    if extracted_text:
                        text += extracted_text + "\n"
                
                if not text:
                    raise ValueError("No text extracted by local parser")
                
                return text
            except Exception as pypdf_e:
                print(f"     ❌ Fallback parsing also failed: {pypdf_e}")
                raise RuntimeError(f"Document parsing failed (LlamaParse & Fallback): {e}")


class DocumentServiceFactory:
    """Factory for creating document parser services."""

    @staticmethod
    def create_parser(parser_type: str = "llama") -> DocumentParser:
        """Create a document parser instance.

        Args:
            parser_type: Type of parser to create

        Returns:
            DocumentParser instance
        """
        if parser_type == "llama":
            return LlamaDocumentService()
        else:
            raise ValueError(f"Unknown parser type: {parser_type}")