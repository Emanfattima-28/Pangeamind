from typing import List
from openai import OpenAI
from config.settings import settings


class EmbeddingService:
    """Service for creating text embeddings using OpenAI."""

    def __init__(self, model: str = None):
        """Initialize the embedding service.

        Args:
            model: The embedding model to use (defaults to settings)
        """
        self.client = OpenAI(api_key=settings.openai_api_key)
        self.model = model or settings.embedding_model

    async def create_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Create embeddings for a list of texts.

        Args:
            texts: List of text strings to embed

        Returns:
            List of embedding vectors

        Raises:
            RuntimeError: If embedding generation fails
        """
        try:
            # OpenAI recommends batching, but has a limit
            batch_size = 100
            all_embeddings = []

            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]

                # Clean texts (remove newlines as per OpenAI docs)
                cleaned_batch = [text.replace("\n", " ") for text in batch]

                response = self.client.embeddings.create(
                    input=cleaned_batch,
                    model=self.model
                )

                batch_embeddings = [data.embedding for data in response.data]
                all_embeddings.extend(batch_embeddings)

            return all_embeddings

        except Exception as e:
            raise RuntimeError(f"Failed to create embeddings: {e}")

    async def create_single_embedding(self, text: str) -> List[float]:
        """Create embedding for a single text.

        Args:
            text: Text string to embed

        Returns:
            Embedding vector

        Raises:
            RuntimeError: If embedding generation fails
        """
        embeddings = await self.create_embeddings([text])
        return embeddings[0] if embeddings else []

    def get_embedding_dimension(self) -> int:
        """Get the dimension of the embedding model.

        Returns:
            Embedding dimension size
        """
        # Model dimensions (can be extended)
        model_dimensions = {
            "text-embedding-3-small": 1536,
            "text-embedding-3-large": 3072,
            "text-embedding-ada-002": 1536
        }
        return model_dimensions.get(self.model, settings.embedding_dimensions)