from abc import ABC, abstractmethod
from typing import List, Dict
import re


class ChunkingStrategy(ABC):
    """Abstract base class for text chunking strategies."""

    @abstractmethod
    def chunk(self, text: str, chunk_size: int = 500, overlap: int = 100) -> List[Dict]:
        """Chunk text into smaller pieces.

        Args:
            text: The text to chunk
            chunk_size: Target size for each chunk
            overlap: Number of words/tokens to overlap between chunks

        Returns:
            List of chunk dictionaries with text and metadata
        """
        pass


class WordBasedChunking(ChunkingStrategy):
    """Simple word-based chunking strategy."""

    def chunk(self, text: str, chunk_size: int = 500, overlap: int = 100) -> List[Dict]:
        """Chunk text based on word count.

        Args:
            text: The text to chunk
            chunk_size: Number of words per chunk
            overlap: Number of words to overlap

        Returns:
            List of chunks with metadata
        """
        # Split text into words
        words = text.split()
        chunks = []

        if len(words) <= chunk_size:
            return [{
                "text": text,
                "chunk_index": 0,
                "word_count": len(words),
                "start_position": 0,
                "end_position": len(text)
            }]

        # Create chunks with overlap
        step_size = chunk_size - overlap
        for i in range(0, len(words), step_size):
            chunk_words = words[i:i + chunk_size]
            chunk_text = " ".join(chunk_words)

            # Calculate character positions
            start_pos = len(" ".join(words[:i])) + (1 if i > 0 else 0)
            end_pos = start_pos + len(chunk_text)

            chunks.append({
                "text": chunk_text,
                "chunk_index": len(chunks),
                "word_count": len(chunk_words),
                "start_position": start_pos,
                "end_position": end_pos
            })

            # Stop if we've processed all words
            if i + chunk_size >= len(words):
                break

        return chunks


class SentenceBasedChunking(ChunkingStrategy):
    """Sentence-aware chunking strategy."""

    def chunk(self, text: str, chunk_size: int = 500, overlap: int = 100) -> List[Dict]:
        """Chunk text based on sentences while respecting word limits.

        Args:
            text: The text to chunk
            chunk_size: Target number of words per chunk
            overlap: Number of words to overlap (approximated with sentences)

        Returns:
            List of chunks with metadata
        """
        # Split into sentences
        sentences = re.split(r'(?<=[.!?])\s+', text)
        chunks = []
        current_chunk = []
        current_word_count = 0

        for sentence in sentences:
            sentence_words = len(sentence.split())

            # If adding this sentence exceeds chunk size, save current chunk
            if current_word_count + sentence_words > chunk_size and current_chunk:
                chunk_text = " ".join(current_chunk)
                chunks.append({
                    "text": chunk_text,
                    "chunk_index": len(chunks),
                    "word_count": current_word_count,
                    "sentence_count": len(current_chunk)
                })

                # Start new chunk with overlap (keep last sentence)
                if overlap > 0 and current_chunk:
                    current_chunk = [current_chunk[-1]]
                    current_word_count = len(current_chunk[0].split())
                else:
                    current_chunk = []
                    current_word_count = 0

            current_chunk.append(sentence)
            current_word_count += sentence_words

        # Add remaining chunk
        if current_chunk:
            chunk_text = " ".join(current_chunk)
            chunks.append({
                "text": chunk_text,
                "chunk_index": len(chunks),
                "word_count": current_word_count,
                "sentence_count": len(current_chunk)
            })

        return chunks


class ChunkingService:
    """Service for text chunking with configurable strategies."""

    def __init__(self, strategy: ChunkingStrategy = None):
        """Initialize with a chunking strategy.

        Args:
            strategy: The chunking strategy to use (defaults to WordBasedChunking)
        """
        self.strategy = strategy or WordBasedChunking()

    def chunk_text(self, text: str, chunk_size: int = 500, overlap: int = 100) -> List[Dict]:
        """Chunk text using the configured strategy.

        Args:
            text: The text to chunk
            chunk_size: Target size for each chunk
            overlap: Overlap between chunks

        Returns:
            List of chunks with metadata
        """
        return self.strategy.chunk(text, chunk_size, overlap)

    def set_strategy(self, strategy: ChunkingStrategy):
        """Change the chunking strategy.

        Args:
            strategy: New chunking strategy to use
        """
        self.strategy = strategy