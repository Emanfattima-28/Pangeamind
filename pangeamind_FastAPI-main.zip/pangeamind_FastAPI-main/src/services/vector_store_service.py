from typing import List, Dict, Optional
from qdrant_client import QdrantClient
from qdrant_client.models import (
    Distance,
    VectorParams,
    PointStruct,
    Filter,
    FieldCondition,
    MatchValue
)
import uuid
from config.settings import settings


class VectorStoreService:
    """Service for managing vector embeddings in Qdrant."""

    def __init__(self, collection_name: str = "documents"):
        """Initialize the vector store service.

        Args:
            collection_name: Name of the Qdrant collection to use
        """
        self.client = QdrantClient(url=settings.qdrant_url)
        self.collection_name = collection_name

    async def create_collection(self, recreate: bool = False):
        """Create or recreate the collection with proper indexes.

        Args:
            recreate: If True, deletes existing collection first
        """
        try:
            import time
            max_retries = 10
            for i in range(max_retries):
                try:
                    # Check if collection exists
                    collections = self.client.get_collections().collections
                    break
                except Exception as e:
                    print(f"Waiting for Qdrant to be ready (attempt {i+1}/{max_retries})...")
                    time.sleep(3)
            else:
                raise RuntimeError("Qdrant did not become ready in time")

            exists = any(c.name == self.collection_name for c in collections)

            if exists and recreate:
                self.client.delete_collection(self.collection_name)
                exists = False

            if not exists:
                # Create collection with vector configuration
                self.client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=VectorParams(
                        size=settings.embedding_dimensions,
                        distance=Distance.COSINE
                    )
                )

                # Create indexes for efficient filtering
                # Index for org_id (tenant index for multi-tenancy)
                self.client.create_payload_index(
                    collection_name=self.collection_name,
                    field_name="org_id",
                    field_schema={
                        "type": "keyword",
                        "is_tenant": True  # Optimizes for multi-tenant queries
                    }
                )

                # Index for doc_id (regular keyword index)
                self.client.create_payload_index(
                    collection_name=self.collection_name,
                    field_name="doc_id",
                    field_schema="keyword"
                )

                # Index for doc_name (regular keyword index)
                self.client.create_payload_index(
                    collection_name=self.collection_name,
                    field_name="doc_name",
                    field_schema="keyword"
                )

                # Index for chunk_index (integer index for ordering)
                self.client.create_payload_index(
                    collection_name=self.collection_name,
                    field_name="chunk_index",
                    field_schema="integer"
                )

                print(f"✅ Collection '{self.collection_name}' created with indexes")

        except Exception as e:
            raise RuntimeError(f"Failed to create collection: {e}")

    async def check_document_exists(
        self,
        org_id: str,
        doc_name: str
    ) -> bool:
        """Check if a document with the same name exists for this org.

        Args:
            org_id: Organization ID
            doc_name: Document name to check

        Returns:
            True if document exists, False otherwise
        """
        try:
            results = self.client.count(
                collection_name=self.collection_name,
                count_filter=Filter(
                    must=[
                        FieldCondition(
                            key="org_id",
                            match=MatchValue(value=org_id)
                        ),
                        FieldCondition(
                            key="doc_name",
                            match=MatchValue(value=doc_name)
                        )
                    ]
                ),
                exact=True
            )
            return results.count > 0
        except Exception:
            return False

    async def store_embeddings(
        self,
        chunks: List[Dict],
        embeddings: List[List[float]],
        org_id: str,
        doc_id: str,
        doc_name: str,
        metadata: Optional[Dict] = None
    ) -> List[str]:
        """Store chunk embeddings in Qdrant.

        Args:
            chunks: List of chunk dictionaries with text and metadata
            embeddings: List of embedding vectors
            org_id: Organization ID for multi-tenant filtering
            doc_id: Unique document ID
            doc_name: Document name (unique per org)
            metadata: Additional metadata to store with each point

        Returns:
            List of generated point IDs

        Raises:
            RuntimeError: If storage fails
        """
        try:
            if len(chunks) != len(embeddings):
                raise ValueError("Number of chunks must match number of embeddings")

            points = []
            point_ids = []

            for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
                # Generate unique ID for this chunk
                point_id = str(uuid.uuid4())
                point_ids.append(point_id)

                # Prepare payload with all metadata
                payload = {
                    "org_id": org_id,
                    "doc_id": doc_id,
                    "doc_name": doc_name,
                    "chunk_text": chunk["text"],
                    "chunk_index": chunk.get("chunk_index", i),
                    "word_count": chunk.get("word_count", 0),
                    "start_position": chunk.get("start_position", 0),
                    "end_position": chunk.get("end_position", 0)
                }

                # Add any additional metadata
                if metadata:
                    payload.update(metadata)

                points.append(
                    PointStruct(
                        id=point_id,
                        vector=embedding,
                        payload=payload
                    )
                )

            # Batch upsert to Qdrant
            self.client.upsert(
                collection_name=self.collection_name,
                points=points,
                wait=True
            )

            print(f"✅ Stored {len(points)} chunks for doc: {doc_name} (ID: {doc_id})")
            return point_ids

        except Exception as e:
            raise RuntimeError(f"Failed to store embeddings: {e}")

    async def search(
        self,
        query_embedding: List[float],
        org_id: Optional[str] = None,
        doc_id: Optional[str] = None,
        doc_name: Optional[str] = None,
        limit: int = 10,
        score_threshold: Optional[float] = None
    ) -> List[Dict]:
        """Search for similar vectors with filtering.

        Args:
            query_embedding: Query vector
            org_id: Filter by organization ID
            doc_id: Filter by document ID
            doc_name: Filter by document name
            limit: Maximum number of results
            score_threshold: Minimum similarity score

        Returns:
            List of search results with metadata
        """
        try:
            # Build filter conditions
            filter_conditions = []

            if org_id:
                filter_conditions.append(
                    FieldCondition(
                        key="org_id",
                        match=MatchValue(value=org_id)
                    )
                )

            if doc_id:
                filter_conditions.append(
                    FieldCondition(
                        key="doc_id",
                        match=MatchValue(value=doc_id)
                    )
                )

            if doc_name:
                filter_conditions.append(
                    FieldCondition(
                        key="doc_name",
                        match=MatchValue(value=doc_name)
                    )
                )

            # Prepare search parameters
            search_params = {
                "collection_name": self.collection_name,
                "query_vector": query_embedding,
                "limit": limit,
                "with_payload": True,
                "with_vectors": False
            }

            if filter_conditions:
                search_params["query_filter"] = Filter(must=filter_conditions)

            if score_threshold:
                search_params["score_threshold"] = score_threshold

            # Perform search
            results = self.client.search(**search_params)

            # Format results
            formatted_results = []
            for result in results:
                formatted_results.append({
                    "id": result.id,
                    "score": result.score,
                    "text": result.payload.get("chunk_text", ""),
                    "metadata": result.payload
                })

            return formatted_results

        except Exception as e:
            raise RuntimeError(f"Failed to search vectors: {e}")

    async def delete_document(self, org_id: str, doc_name: str) -> int:
        """Delete all chunks for a specific document.

        Args:
            org_id: Organization ID
            doc_name: Document name to delete

        Returns:
            Number of deleted points
        """
        try:
            # Delete points matching both org_id and doc_name
            result = self.client.delete(
                collection_name=self.collection_name,
                points_selector=Filter(
                    must=[
                        FieldCondition(
                            key="org_id",
                            match=MatchValue(value=org_id)
                        ),
                        FieldCondition(
                            key="doc_name",
                            match=MatchValue(value=doc_name)
                        )
                    ]
                ),
                wait=True
            )

            print(f"✅ Deleted document: {doc_name} for org: {org_id}")
            return result

        except Exception as e:
            raise RuntimeError(f"Failed to delete document: {e}")