import json
import os
from datetime import datetime
from typing import List, Dict
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from config.settings import settings
from models.chat import ChatResponse


class ChatService:
    """Chat service with document search capabilities."""

    def __init__(self, rag_service=None):
        """Initialize chat service with RAG pipeline.

        Args:
            rag_service: RAG pipeline service for document search
        """
        self.rag_service = rag_service
        self.conversations_file = "conversations.json"
        self.model = ChatOpenAI(
            model="gpt-4o-mini",
            api_key=settings.openai_api_key,
            temperature=0.1
        )

        # Create list_documents tool
        @tool
        def list_documents(org_id: str = "default") -> str:
            """List all available documents that have been uploaded.

            Use this when users ask about 'the file', 'this document', or want to know what's available.

            Parameters
            ----------
            org_id : str, optional
                Organization ID to filter documents (default: "default")

            Returns
            -------
            str
                List of available document names
            """
            try:
                if not self.rag_service:
                    return "Error: Document search service not available"

                import asyncio
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

                try:
                    # Get all documents by doing a broad search
                    search_response = loop.run_until_complete(
                        self.rag_service.search(
                            query="document",  # Broad query to get any documents
                            org_id=org_id,
                            limit=50,
                            score_threshold=0.0
                        )
                    )
                finally:
                    loop.close()

                if not search_response.results:
                    return "No documents have been uploaded yet."

                # Extract unique document names
                doc_names = set()
                for result in search_response.results:
                    doc_name = result['metadata'].get('doc_name', 'Unknown')
                    doc_names.add(doc_name)

                doc_list = '\n'.join([f"- {name}" for name in sorted(doc_names)])
                return f"Available documents ({len(doc_names)}):\n{doc_list}\n\nYou can ask me questions about any of these documents!"

            except Exception as e:
                return f"Error listing documents: {str(e)}"

        # Create search_docs tool
        @tool
        def search_docs(query: str, org_id: str = "default", limit: int = 5) -> str:
            """Search through uploaded documents for relevant information.

            Parameters
            ----------
            query : str
                The search query to find relevant document chunks
            org_id : str, optional
                Organization ID to filter documents (default: "default")
            limit : int, optional
                Maximum number of results to return (default: 5)

            Returns
            -------
            str
                Formatted search results with relevant document chunks
            """
            try:
                if not self.rag_service:
                    return "Error: Document search service not available"

                # Perform search using RAG service
                import asyncio
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

                try:
                    search_response = loop.run_until_complete(
                        self.rag_service.search(
                            query=query,
                            org_id=org_id,
                            limit=limit,
                            score_threshold=0.1
                        )
                    )
                finally:
                    loop.close()

                if not search_response.results:
                    return f"No relevant documents found for query: '{query}'"

                # Format results
                formatted_results = []
                for i, result in enumerate(search_response.results, 1):
                    formatted_results.append(
                        f"Result {i} (Score: {result['score']:.3f}):\n"
                        f"Document: {result['metadata'].get('doc_name', 'Unknown')}\n"
                        f"Content: {result['text'][:500]}...\n"
                    )

                return f"Found {len(search_response.results)} relevant documents:\n\n" + "\n---\n".join(formatted_results)

            except Exception as e:
                return f"Error searching documents: {str(e)}"

        # Create the agent with search tool
        self.agent = create_react_agent(
            model=self.model,
            tools=[list_documents, search_docs],
            prompt="""
You are a helpful AI assistant that can search through uploaded documents to answer user questions.

You have access to two tools:
1. list_documents - Use this to see what documents are available
2. search_docs - Use this to search for specific information within documents

Guidelines:
1. When users ask vague questions like "what is this file about?" or "tell me about the document", FIRST use list_documents to see what's available, THEN search for relevant content
2. When users ask about specific topics (e.g., "admission requirements", "vector search"), directly use search_docs with that topic
3. Always search documents when the user asks questions that might be answered by document content
4. Provide clear, concise answers based on the search results (limit responses to 500 words)
5. If no relevant documents are found, let the user know
6. Quote specific information from documents when relevant
7. Be conversational and helpful
8. NEVER repeat the same information multiple times
9. If you find relevant information, summarize it clearly and stop

Examples:
- User: "What is this file about?" → Use list_documents first, then search based on the document name
- User: "Tell me about the document" → Use list_documents first, then search with relevant keywords
- User: "What are admission requirements?" → Use search_docs with "admission requirements"
- User: "Tell me about vector search" → Use search_docs with "vector search"
- User: "What documents do I have?" → Use list_documents

Always be helpful and provide context about where information comes from. Keep responses concise and avoid repetition.
"""
        )

    def _load_conversations(self) -> Dict[str, List[Dict]]:
        """Load conversations from JSON file."""
        if not os.path.exists(self.conversations_file):
            return {}

        try:
            with open(self.conversations_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {}

    def _save_conversations(self, conversations: Dict[str, List[Dict]]):
        """Save conversations to JSON file."""
        try:
            with open(self.conversations_file, 'w', encoding='utf-8') as f:
                json.dump(conversations, f, indent=2, ensure_ascii=False, default=str)
        except Exception as e:
            print(f"Warning: Failed to save conversations: {e}")

    def _get_session_messages(self, session_id: str) -> List[Dict]:
        """Get message history for a session."""
        conversations = self._load_conversations()
        return conversations.get(session_id, [])

    def _save_session_message(self, session_id: str, role: str, content: str):
        """Save a message to session history."""
        conversations = self._load_conversations()

        if session_id not in conversations:
            conversations[session_id] = []

        conversations[session_id].append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })

        # Keep only last 20 messages per session to avoid huge files
        if len(conversations[session_id]) > 20:
            conversations[session_id] = conversations[session_id][-20:]

        self._save_conversations(conversations)

    async def chat(
        self,
        message: str,
        session_id: str = "default",
        org_id: str = "default"
    ) -> ChatResponse:
        """Process a chat message and return response.

        Args:
            message: User message
            session_id: Session ID for conversation history
            org_id: Organization ID for document filtering

        Returns:
            Chat response with message and metadata
        """
        try:
            # Save user message
            self._save_session_message(session_id, "user", message)

            # Get recent conversation history
            history = self._get_session_messages(session_id)

            # Build messages 
            recent_messages = []
            # for msg in history[-10:]:
            for msg in history:
                if msg["role"] in ["user", "assistant"]:
                    recent_messages.append((msg["role"], msg["content"]))

            # Add current message if not already in history
            if not recent_messages or recent_messages[-1][1] != message:
                recent_messages.append(("user", message))

            # Invoke the agent
            result = self.agent.invoke({"messages": recent_messages})

            # Extract the final assistant message
            assistant_message = ""
            for msg in result["messages"]:
                if hasattr(msg, 'type') and msg.type == "ai":
                    assistant_message = msg.content
                elif hasattr(msg, 'content'):
                    assistant_message = msg.content

            if not assistant_message and result["messages"]:
                # Fallback to last message content
                assistant_message = str(result["messages"][-1].content if hasattr(result["messages"][-1], 'content') else result["messages"][-1])

            # Save assistant response
            self._save_session_message(session_id, "assistant", assistant_message)

            return ChatResponse(
                response=assistant_message,
                session_id=session_id,
                timestamp=datetime.now().isoformat(),
                org_id=org_id
            )

        except Exception as e:
            error_msg = f"Sorry, I encountered an error: {str(e)}"
            self._save_session_message(session_id, "assistant", error_msg)
            return ChatResponse(
                response=error_msg,
                session_id=session_id,
                timestamp=datetime.now().isoformat(),
                org_id=org_id,
                error=True
            )

    def get_conversation_history(self, session_id: str) -> List[Dict]:
        """Get conversation history for a session."""
        return self._get_session_messages(session_id)

    def clear_conversation(self, session_id: str) -> bool:
        """Clear conversation history for a session."""
        try:
            conversations = self._load_conversations()
            if session_id in conversations:
                del conversations[session_id]
                self._save_conversations(conversations)
            return True
        except Exception:
            return False