# src/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

# Routers
from api.routers import documents, search, health, chat, guest_token
# Auth
from api.auth import verify_server_key
# Settings
from config.settings import settings
# Services
from services.rag_pipeline_service import RAGPipelineService
from services.chat_service import ChatService

# Initialize services
rag_service = RAGPipelineService()
chat_service = ChatService()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle."""
    print("🚀 Starting PangeaMind AI Platform...")

    # Initialize RAG pipeline
    await rag_service.initialize()
    print("✅ RAG Pipeline initialized")

    # Attach services to routers
    documents.rag_service = rag_service
    search.rag_service = rag_service
    chat_service.rag_service = rag_service
    chat.chat_service = chat_service

    yield

    print("👋 Shutting down PangeaMind AI Platform...")


# Create FastAPI app
app = FastAPI(
    title="PangeaMind AI Platform",
    description=(
        "RAG-based document processing and AI chat API.\n\n"
        "## Authentication\n\n"
        "### Public / Shared Agent Endpoints\n"
        "Endpoints under `/chat` and `/search` require a **Guest Token**.\n"
        "Pass it via header `X-Guest-Token` or query param `?guest_token=`.\n\n"
        "### Server-to-Server Endpoints\n"
        "Endpoints under `/documents` and `/guest-token` require a **Server Key**.\n"
        "Pass it via header `X-Server-Key`. **Never expose this key in client code.**"
    ),
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers with proper prefixes
app.include_router(health.router)
app.include_router(guest_token.router, prefix="/api/v1")
app.include_router(documents.router, prefix="/api/v1")
app.include_router(search.router, prefix="/api/v1")
app.include_router(chat.router, prefix="/api/v1")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "src.main:app",  # Must match the module path
        host="0.0.0.0",
        port=3100,
        reload=True,
        log_level="info"
    )