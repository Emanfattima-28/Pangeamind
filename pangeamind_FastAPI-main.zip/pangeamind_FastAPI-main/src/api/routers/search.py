from fastapi import APIRouter, Depends, HTTPException
from services.rag_pipeline_service import RAGPipelineService
from models.document import DocumentSearchRequest, DocumentSearchResponse
from typing import Optional
from api.auth import get_optional_org_from_guest_token  # ← guest token dependency


router = APIRouter(
    prefix="/search",
    tags=["search"],
    responses={
        404: {"description": "Not found"},
        401: {"description": "Guest token missing or invalid"},
    },
)

# Initialize service
rag_service = RAGPipelineService()


@router.post("/", response_model=DocumentSearchResponse)
async def search_documents(
    request: DocumentSearchRequest,
    token_org_id: Optional[str] = Depends(get_optional_org_from_guest_token),
):
    """
    Search for relevant document chunks.

    **Requires a valid guest token** or `api_key_mode == "public"`.
    """
    try:
        if request.api_key_mode == "public" and request.org_id:
            org_id = request.org_id
        else:
            if not token_org_id:
                raise HTTPException(
                    status_code=401,
                    detail="Authentication required. Provide a valid guest token or use public API key mode."
                )
            org_id = token_org_id

        # Override any org_id in the body with the one from our auth step
        request.org_id = org_id
        
        results = await rag_service.process_search_request(request)
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))