from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from typing import Optional
import os
from api.auth import verify_server_key  # ← server key dependency
import tempfile
from services.rag_pipeline_service import RAGPipelineService


router = APIRouter(
    prefix="/documents",
    tags=["documents"],
    responses={
        404: {"description": "Not found"},
        403: {"description": "X-Server-Key header is missing or invalid"},
    },
)

# Initialize service
rag_service = RAGPipelineService()


@router.post("/upload", dependencies=[Depends(verify_server_key)])
async def upload_document(
    file: UploadFile = File(...),
    org_id: str = "default",
    doc_name: Optional[str] = None,
):
    """Upload and process a document based on file type.

    **Requires X-Server-Key header** — server-to-server only.
    This endpoint triggers LlamaParse + OpenAI embedding which incurs API costs.

    Args:
        file: Document file to upload
        org_id: Organization ID for multi-tenancy
        doc_name: Document name (must be unique per org)

    Returns:
        Success response with document details
    """
    try:
        # Get file extension
        file_ext = os.path.splitext(file.filename)[1].lower()

        # Check if file type is supported
        if file_ext != '.pdf':
            raise HTTPException(
                status_code=400,
                detail=f"File type '{file_ext}' is not supported. Currently only PDF files (.pdf) are supported."
            )

        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=file_ext) as tmp_file:
            content = await file.read()
            tmp_file.write(content)
            tmp_file_path = tmp_file.name

        try:
            # Use filename as doc_name if not provided
            if not doc_name:
                doc_name = os.path.splitext(file.filename)[0]  # Remove extension

            # Check if document with this name already exists
            if await rag_service.vector_store.check_document_exists(org_id, doc_name):
                raise HTTPException(
                    status_code=400,
                    detail=f"Document with name '{doc_name}' already exists for organization '{org_id}'"
                )

            # Process the document based on file type
            if file_ext == '.pdf':
                document = await rag_service.process_document(
                    file_path=tmp_file_path,
                    org_id=org_id,
                    doc_name=doc_name,
                    metadata={
                        "original_filename": file.filename,
                        "content_type": file.content_type,
                        "file_type": file_ext
                    }
                )
            # Add more file types here in the future (e.g., .txt, .docx, .html)
            # elif file_ext == '.txt':
            #     await process_text_document(...)

            return JSONResponse(
                status_code=200,
                content={
                    "status": "success",
                    "message": f"Document '{file.filename}' processed successfully",
                    "doc_id": document.doc_id,
                    "doc_name": doc_name,
                    "org_id": org_id,
                    "file_type": file_ext
                }
            )

        finally:
            # Clean up temporary file
            os.unlink(tmp_file_path)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{doc_name}", dependencies=[Depends(verify_server_key)])
async def delete_document(doc_name: str, org_id: str = "default"):
    """Delete a document from the vector store.

    **Requires X-Server-Key header** — server-to-server only.

    Args:
        doc_name: Document name to delete
        org_id: Organization ID

    Returns:
        Success response
    """
    try:
        success = await rag_service.delete_document(org_id, doc_name)
        if success:
            return JSONResponse(
                status_code=200,
                content={
                    "status": "success",
                    "message": f"Document '{doc_name}' deleted successfully"
                }
            )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))