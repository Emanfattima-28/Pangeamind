from fastapi import APIRouter


router = APIRouter(
    tags=["health"],
    responses={404: {"description": "Not found"}},
)


@router.get("/")
async def root():
    """Root endpoint."""
    return {"message": "PangeaMind AI Platform API"}


@router.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "PangeaMind AI Platform",
        "version": "0.1.0"
    }


@router.get("/ready")
async def readiness_check():
    """Readiness check for Kubernetes/Docker deployments."""
    # Add checks for database, services, etc.
    return {
        "status": "ready",
        "services": {
            "qdrant": "connected",
            "llama_parse": "ready",
            "openai": "ready"
        }
    }