"""
Guest Token Router
==================
Issues short-lived, org-scoped guest tokens for public/shared agent access.

WHO CALLS THIS:
  Your main application backend (server-to-server).
  NEVER called directly from browser JS or mobile apps.

HOW IT WORKS:
  1. User opens a shared agent URL on your frontend
  2. Your backend (Next.js / .NET / Django / etc.) calls:
       POST /api/v1/guest-token/
       Header: X-Server-Key: <server_api_key>
       Body:   { "org_id": "your_org_id", "max_requests": 100 }
  3. Returns a signed JWT valid for 60 minutes
  4. Your backend embeds the token in the rendered HTML / passes it to
     the widget via a JS variable or a <meta> tag
  5. The widget uses the token on every chat/search call via X-Guest-Token header
"""

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from typing import Optional

from api.auth import create_guest_token, verify_server_key


router = APIRouter(
    prefix="/guest-token",
    tags=["authentication"],
    responses={
        403: {"description": "X-Server-Key header is missing or invalid"},
    },
)


# ---------------------------------------------------------------------------
# Request / Response Models
# ---------------------------------------------------------------------------

class GuestTokenRequest(BaseModel):
    """Body sent by YOUR backend to request a guest token."""

    org_id: str = Field(
        ...,
        description="Organization ID whose documents this token grants access to.",
        examples=["org_abc123"],
    )
    max_requests: Optional[int] = Field(
        default=100,
        ge=1,
        le=1000,
        description=(
            "Informational cap on how many API calls this token allows. "
            "Stored in the JWT payload. Hard enforcement requires a Redis counter."
        ),
    )


class GuestTokenResponse(BaseModel):
    """Returned to your backend — pass guest_token to your frontend widget."""

    guest_token: str = Field(description="Signed JWT. Embed in your widget.")
    org_id: str = Field(description="The org this token is scoped to.")
    expires_at: str = Field(description="ISO-8601 expiry timestamp (UTC).")
    max_requests: int = Field(description="Request cap stored in token.")
    ttl_minutes: int = Field(description="Token lifetime in minutes.")


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------

@router.post(
    "/",
    response_model=GuestTokenResponse,
    summary="Issue a guest token (server-to-server only)",
    description="""
Issue a short-lived, org-scoped guest token.

**Requires `X-Server-Key` header** — this is your long-lived server secret.

Use the returned `guest_token` in your public chat widget:
```
X-Guest-Token: <guest_token>
```
or as a query parameter:
```
?guest_token=<guest_token>
```
""",
    dependencies=[Depends(verify_server_key)],  # Server key validated here
)
async def issue_guest_token(request: GuestTokenRequest) -> GuestTokenResponse:
    """
    Issue a guest token for a specific organization.

    Your backend calls this once per shared-agent page load,
    then passes the token to the browser widget.
    """
    result = create_guest_token(
        org_id=request.org_id,
        max_requests=request.max_requests,
    )
    return GuestTokenResponse(**result)


@router.get(
    "/verify",
    summary="Verify a guest token (debug/testing only)",
    description="Decodes and validates a guest token. Useful during development to confirm tokens are working.",
)
async def verify_guest_token_debug(
    guest_token: str,
    _=Depends(verify_server_key),
):
    """
    Debug endpoint — verify a guest token and see its claims.
    Remove or protect this in production.
    """
    from jose import jwt as jose_jwt
    from config.settings import settings
    try:
        payload = jose_jwt.decode(guest_token, settings.guest_token_secret, algorithms=["HS256"])
        return {
            "valid": True,
            "claims": payload,
        }
    except Exception as e:
        return {
            "valid": False,
            "error": str(e),
        }
