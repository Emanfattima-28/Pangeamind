from fastapi import APIRouter, Depends, HTTPException
from typing import Optional
from services.chat_service import ChatService
from models.chat import (
    ChatRequest,
    ChatResponse,
    ConversationHistoryResponse,
    ConversationMessage,
    ClearHistoryResponse
)
from api.auth import get_org_from_guest_token, get_optional_org_from_guest_token


router = APIRouter(
    prefix="/chat",
    tags=["chat"],
    responses={
        404: {"description": "Not found"},
        401: {"description": "Guest token missing or invalid"},
    },
)

# Initialize service (will be set in main.py)
chat_service: Optional[ChatService] = None


@router.post("/", response_model=ChatResponse)
async def chat_with_documents(
    request: ChatRequest,
    token_org_id: Optional[str] = Depends(get_optional_org_from_guest_token),
):
    """
    Chat with the AI assistant.

    **Requires a valid guest token** or `api_key_mode == "public"`.
    """
    try:
        if not chat_service:
            raise HTTPException(status_code=500, detail="Chat service not initialized")

        # Bypass auth for public API key mode
        if request.api_key_mode == "public" and request.org_id:
            org_id = request.org_id
        else:
            if not token_org_id:
                raise HTTPException(
                    status_code=401,
                    detail="Authentication required. Provide a valid guest token or use public API key mode."
                )
            org_id = token_org_id

        response = await chat_service.chat(
            message=request.message,
            session_id=request.session_id,
            org_id=org_id,
        )

        return response

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history/{session_id}", response_model=ConversationHistoryResponse)
async def get_conversation_history(
    session_id: str,
    api_key_mode: Optional[str] = None,
    org_id: Optional[str] = None,
    token_org_id: Optional[str] = Depends(get_optional_org_from_guest_token),
):
    """
    Get conversation history for a session.

    **Requires a valid guest token** or `api_key_mode == "public"`.
    """
    try:
        if api_key_mode == "public" and org_id:
            pass
        elif not token_org_id:
            raise HTTPException(
                status_code=401,
                detail="Authentication required. Provide a valid guest token or use public API key mode."
            )

        if not chat_service:
            raise HTTPException(status_code=500, detail="Chat service not initialized")

        history = chat_service.get_conversation_history(session_id)

        return ConversationHistoryResponse(
            session_id=session_id,
            messages=[ConversationMessage(**msg) for msg in history],
            total_messages=len(history)
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/history/{session_id}", response_model=ClearHistoryResponse)
async def clear_conversation_history(
    session_id: str,
    api_key_mode: Optional[str] = None,
    org_id: Optional[str] = None,
    token_org_id: Optional[str] = Depends(get_optional_org_from_guest_token),
):
    """
    Clear conversation history for a session.

    **Requires a valid guest token** or `api_key_mode == "public"`.
    """
    try:
        if api_key_mode == "public" and org_id:
            pass
        elif not token_org_id:
            raise HTTPException(
                status_code=401,
                detail="Authentication required. Provide a valid guest token or use public API key mode."
            )

        if not chat_service:
            raise HTTPException(status_code=500, detail="Chat service not initialized")

        success = chat_service.clear_conversation(session_id)

        if success:
            return ClearHistoryResponse(
                status="success",
                message=f"Conversation history cleared for session: {session_id}"
            )
        else:
            raise HTTPException(
                status_code=500,
                detail="Failed to clear conversation history"
            )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))