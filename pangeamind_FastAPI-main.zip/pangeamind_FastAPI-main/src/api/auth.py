"""
PangeaMind Authentication Utilities
=====================================
Two-tier access control:

  Tier 1 — Server Key (X-Server-Key header)
    • Long-lived secret known ONLY to your backend server
    • Used for: document upload, document delete, issuing guest tokens
    • NEVER exposed to browsers or mobile apps

  Tier 2 — Guest Token (X-Guest-Token header or ?guest_token= query param)
    • Short-lived signed JWT (default: 60 min)
    • Scoped to one org_id — cannot pivot to other orgs
    • Issued by your backend when rendering a shared-agent page
    • Passed by the browser widget on every chat/search request
    • Safe to expose in browser — it expires and is scoped
"""

from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import Depends, Header, HTTPException, Query
from jose import JWTError, jwt

from config.settings import settings

# JWT algorithm — HMAC-SHA256 is fast and sufficient for short-lived tokens
ALGORITHM = "HS256"
TOKEN_TYPE_GUEST = "guest"


# ---------------------------------------------------------------------------
# Token Creation
# ---------------------------------------------------------------------------

def create_guest_token(org_id: str, max_requests: int = 100) -> dict:
    """
    Create a signed, short-lived guest token scoped to one org_id.

    Call this SERVER-SIDE ONLY — never from browser code.

    Parameters
    ----------
    org_id : str
        The organization whose documents this token grants access to.
    max_requests : int
        Informational cap stored in the token (not enforced by default,
        add Redis counter if you need hard enforcement).

    Returns
    -------
    dict with keys: guest_token, org_id, expires_at, max_requests
    """
    now = datetime.now(tz=timezone.utc)
    expire = now + timedelta(minutes=settings.guest_token_ttl_minutes)

    payload = {
        "type": TOKEN_TYPE_GUEST,          # Distinguish from other token kinds
        "org_id": org_id,                  # Scoped org — cannot be changed by client
        "max_requests": max_requests,       # Informational limit
        "iat": now,                         # Issued at
        "exp": expire,                      # Expiry — jose enforces this automatically
    }

    token = jwt.encode(payload, settings.guest_token_secret, algorithm=ALGORITHM)

    return {
        "guest_token": token,
        "org_id": org_id,
        "expires_at": expire.isoformat(),
        "max_requests": max_requests,
        "ttl_minutes": settings.guest_token_ttl_minutes,
    }


# ---------------------------------------------------------------------------
# Token Verification
# ---------------------------------------------------------------------------

def _decode_guest_token(token: str) -> dict:
    """
    Internal: decode and validate a guest JWT.
    Raises HTTP 401 on any failure (expired, bad signature, wrong type).
    """
    try:
        payload = jwt.decode(
            token,
            settings.guest_token_secret,
            algorithms=[ALGORITHM],
        )
    except JWTError:
        raise HTTPException(
            status_code=401,
            detail=(
                "Guest token is invalid or has expired. "
                "Please refresh the page to receive a new token."
            ),
        )

    if payload.get("type") != TOKEN_TYPE_GUEST:
        raise HTTPException(
            status_code=401,
            detail="Token type mismatch. Expected a guest token.",
        )

    if not payload.get("org_id"):
        raise HTTPException(
            status_code=401,
            detail="Guest token is missing org_id claim.",
        )

    return payload


# ---------------------------------------------------------------------------
# FastAPI Dependencies
# ---------------------------------------------------------------------------

async def get_org_from_guest_token(
    x_guest_token: Optional[str] = Header(
        default=None,
        description="Short-lived guest JWT issued by your backend server.",
        alias="x-guest-token",
    ),
    guest_token: Optional[str] = Query(
        default=None,
        description="Same guest JWT passed as query param (for iframe/widget use).",
    ),
) -> str:
    """
    FastAPI dependency — validates the guest token and returns the org_id.

    Usage in a router:
        @router.post("/")
        async def endpoint(org_id: str = Depends(get_org_from_guest_token)):
            ...

    Accepts the token via EITHER:
      • HTTP header:  X-Guest-Token: <token>
      • Query param:  ?guest_token=<token>   (useful for embedded widgets)

    Returns
    -------
    str — the org_id encoded in the token (cannot be spoofed by the client)
    """
    token = x_guest_token or guest_token

    if not token:
        raise HTTPException(
            status_code=401,
            detail=(
                "Authentication required. "
                "Provide a guest token via the X-Guest-Token header "
                "or the ?guest_token= query parameter."
            ),
        )

    payload = _decode_guest_token(token)
    return payload["org_id"]


async def get_optional_org_from_guest_token(
    x_guest_token: Optional[str] = Header(
        default=None,
        description="Short-lived guest JWT issued by your backend server.",
        alias="x-guest-token",
    ),
    guest_token: Optional[str] = Query(
        default=None,
        description="Same guest JWT passed as query param (for iframe/widget use).",
    ),
    authorization: Optional[str] = Header(
        default=None,
        description="Legacy fallback for Authorization: Bearer <token>"
    )
) -> Optional[str]:
    """
    Optional guest token validator. Returns org_id if valid, None if missing or invalid.
    """
    token = x_guest_token or guest_token
    if not token and authorization and authorization.startswith("Bearer "):
        token = authorization.split(" ")[1]

    if not token:
        return None

    try:
        payload = _decode_guest_token(token)
        return payload["org_id"]
    except HTTPException:
        return None


def verify_server_key(
    x_server_key: Optional[str] = Header(
        default=None,
        description="Long-lived server-to-server API key. Never expose in client code.",
        alias="x-server-key",
    ),
) -> None:
    """
    FastAPI dependency — validates the server API key.

    Use this on admin/internal endpoints:
      • POST /guest-token/     (issue guest tokens)
      • POST /documents/upload (ingest PDFs)
      • DELETE /documents/{name}

    Usage in a router:
        @router.post("/upload", dependencies=[Depends(verify_server_key)])
        async def upload(...):
            ...
    """
    if not x_server_key or x_server_key != settings.server_api_key:
        raise HTTPException(
            status_code=403,
            detail=(
                "Forbidden. This endpoint requires a valid X-Server-Key header. "
                "It is intended for server-to-server calls only."
            ),
        )
