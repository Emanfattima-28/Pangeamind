from llama_cloud_services import LlamaParse
import asyncio

async def main():
    
    result = await LlamaParse(
        # The parsing mode
        parse_mode="parse_page_with_agent",
        # The model to use
        model="openai-gpt-4-1-mini",
        # Whether to use high resolution OCR (Slower)
        high_res_ocr=True,
        # Adaptive long table. LlamaParse will try to detect long tables across pages
        adaptive_long_table=True,
        outlined_table_extraction=True,
        output_tables_as_HTML=True,
        # Whether to take a screenshot of the page, needed for screenshot-retrieval
        take_screenshot=True,
    ).aparse("./apple_2021_10k.pdf")

    print(result)

if __name__ == "__main__":
    asyncio.run(main())