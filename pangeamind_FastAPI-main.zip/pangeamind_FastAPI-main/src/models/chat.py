from pydantic import BaseModel
from typing import Optional, List, Dict, Any


class ChatRequest(BaseModel):
    """Request model for chat messages."""
    message: str
    session_id: Optional[str] = "default"
    org_id: Optional[str] = "default"
    api_key_mode: Optional[str] = None


class ChatResponse(BaseModel):
    """Response model for chat messages."""
    response: str
    session_id: str
    timestamp: str
    org_id: str
    error: Optional[bool] = False


class ConversationMessage(BaseModel):
    """Model for a single conversation message."""
    role: str
    content: str
    timestamp: str


class ConversationHistoryResponse(BaseModel):
    """Response model for conversation history."""
    session_id: str
    messages: List[ConversationMessage]
    total_messages: int


class ClearHistoryResponse(BaseModel):
    """Response model for clearing conversation history."""
    status: str
    message: str
