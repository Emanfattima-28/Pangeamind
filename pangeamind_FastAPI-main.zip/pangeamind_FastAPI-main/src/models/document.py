from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from uuid_extensions import uuid7


class Chunk(BaseModel):
    """Model for a document chunk."""
    text: str
    chunk_index: int
    word_count: int
    start_position: int
    end_position: int
    embedding: Optional[List[float]] = None


class Document(BaseModel):
    """Model for a document."""
    doc_id: str = Field(default_factory=lambda: str(uuid7()))
    doc_name: str
    org_id: str
    file_type: str = "pdf"
    created_at: datetime = Field(default_factory=datetime.now)
    chunks: List[Chunk] = []
    metadata: Optional[dict] = None


class DocumentUploadRequest(BaseModel):
    """Request model for document upload."""
    file_path: str
    org_id: str
    doc_name: str
    metadata: Optional[dict] = None


class DocumentSearchRequest(BaseModel):
    """Request model for document search."""
    query: str
    org_id: Optional[str] = None
    doc_id: Optional[str] = None
    doc_name: Optional[str] = None
    limit: int = 10
    score_threshold: Optional[float] = None
    api_key_mode: Optional[str] = None


class DocumentSearchResponse(BaseModel):
    """Response model for document search."""
    results: List[dict]
    query: str
    total_results: int