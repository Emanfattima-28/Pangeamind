from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    # --- External service keys (required) ---
    llama_parse_api_key: str
    openai_api_key: str

    # --- Qdrant vector store ---
    qdrant_url: str = "http://localhost:6333"

    # --- Embedding model ---
    embedding_model: str = "text-embedding-3-small"
    embedding_dimensions: int = 1536

    # --- Document chunking ---
    chunk_size: int = 500
    chunk_overlap: int = 100

    # --- Security: Guest Token (Tier 2) ---
    # Used to sign/verify short-lived guest JWTs for public shared agents.
    # MUST be overridden in production with a long random string (32+ chars).
    guest_token_secret: str = "CHANGE_ME_IN_PRODUCTION_MIN_32_CHARS_RANDOM"
    guest_token_ttl_minutes: int = 60        # Guest tokens expire after 1 hour

    # --- Security: Server API Key (Tier 1) ---
    # Long-lived key for server-to-server calls (upload, delete, token issuing).
    # NEVER expose this in browser code or client apps.
    server_api_key: str = "CHANGE_ME_SERVER_ONLY_SECRET_KEY"

    # --- CORS: Lock down in production ---
    # Example: ["https://app.pangeamind.com", "https://pangeamind.com"]
    allowed_origins: List[str] = ["*"]

    class Config:
        env_file = ".env"


settings = Settings()