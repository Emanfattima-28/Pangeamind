# Use Python 3.11
FROM python:3.11

# Set working directory inside container
WORKDIR /app

# Copy frontend folder into container
COPY ./frontend /app

# Install dependencies
RUN pip install --no-cache-dir streamlit fastapi uvicorn

# Expose Streamlit port
EXPOSE 8501

# Run the Streamlit app
CMD ["streamlit", "run", "streamlit_app.py", "--server.port=8501", "--server.address=0.0.0.0"]