# PangeaMind AI Platform

A production-ready RAG (Retrieval-Augmented Generation) platform for document processing, embedding, and intelligent search using Qdrant vector database.

## 🚀 Key Features

- **Omni-Parser with Fallback**: Dual-layer PDF processing using **LlamaParse** (high-accuracy) with automatic fallback to **pypdf** (local/offline) if API quotas are reached.
- **Microservice Architecture**: Fully containerized with Docker, featuring FastAPI backend, Streamlit frontend, and Qdrant vector store.
- **Smart RAG Pipeline**: Intelligent chunking (word or sentence-based) and semantic indexing with OpenAI embeddings.
- **Dual Authentication**:
    - **Guest Tokens**: Short-lived, organization-scoped JWTs for public agent access.
    - **Server Keys**: Secure API key protection for administrative document management.
- **Ready-to-Use Frontend**: Premium Streamlit interface for document uploads, real-time chat, and history management.
- **Robust Testing**: Comprehensive test suite including 20+ unit tests with mocks for offline verification.

---

## ⚡ Quick Start (The "One-Command" Run)

The easiest way to see the platform in action:

```bash
# 1. Start everything (Database + API + UI) via Docker
docker compose up -d --build

# 2. Access the applications
# UI: http://localhost:8501
# API Docs: http://localhost:3100/docs
# DB Dashboard: http://localhost:6333/dashboard
```

---

## 📋 Prerequisites

- **Docker & Docker Compose**
- **Python 3.12+** (for local development)
- **API Keys**: OpenAI API Key and LlamaParse API Key (stored in `.env`)

---

## 🛠️ Installation & Setup

### 1. Configure Environment
Rename `.env.example` to `.env` and add your keys:
```env
LLAMA_PARSE_API_KEY=your_key_here
OPENAI_API_KEY=your_key_here
QDRANT_URL=http://qdrant:6333
```

### 2. Local Development (No Docker for App)
If you want to edit code and see changes instantly:

```bash
# Start only the database
docker compose up -d qdrant

# Run the local launcher (starts FastAPI + Streamlit)
python run_app.py
```

---

## 🧪 Testing & Verification

We provide zero-cost testing tools to verify your installation without spending API credits.

### 1. Cost-Free Unit Tests (20 Tests)
Verifies the entire logic of the RAG pipeline, parsing, and vector store using Mocks.
```bash
# Install test requirements
pip install pytest pytest-asyncio pypdf

# Run the suite
export PYTHONPATH=src
pytest tests/test_document_service.py -v
```
**Expectation:** `20 passed`

### 2. Command-Line RAG Test
Test the full pipeline (Parsing -> Embedding -> Search) via CLI:
```bash
python query_test.py --file data_files/sample-llm-application.pdf --query "What is this about?"
```

---

## 📡 API Authentication

| Endpoint Group | Auth Method | Header |
|----------------|-------------|--------|
| `/api/v1/documents` | Server Key | `X-Server-Key` |
| `/api/v1/chat` | Guest Token | `X-Guest-Token` or `?guest_token=` |
| `/api/v1/search` | Guest Token | `X-Guest-Token` |

---

## 📁 Project Structure

```text
pangeamind_FastAPI/
├── src/
│   ├── api/routers/      # API Endpoints (Chat, Docs, Search)
│   ├── services/         # Core Logic (RAG, Embedding, VectorStore)
│   ├── models/           # Data Structures
│   └── main.py           # FastAPI Application Entry
├── frontend/             # Streamlit Application
├── tests/                # Unit & Integration Tests
├── data_files/           # Sample PDF library
├── docker-compose.yml    # Full Stack Orchestration
└── run_app.py            # Local Dev Stack Launcher
```

---

## 🚧 Troubleshooting

- **Site can't be reached (Streamlit):** Ensure port `8501` is not blocked. If running for the first time, check the terminal for the Streamlit "Welcome" prompt and press Enter.
- **Refused Connection (FastAPI):** Check if `docker compose up -d qdrant` was successful. The API requires Qdrant to be active to start.
- **Quota Errors:** If you see `insufficient_quota`, the system will use the `pypdf` fallback for parsing, but you must have OpenAI credits for embeddings/chat.

---

## 🤝 Contributing
Contributions are welcome! Please follow the standard fork-and-pull-request workflow.

## 📄 License
MIT License. See LICENSE for details.