"""
STREAMLIT DOCUMENT CHAT APP
Advanced chat interface that integrates with Document Service API
Features document upload, chat with streaming responses, and conversation history
"""

import streamlit as st
import requests
import time
from typing import Generator, Dict, Any
import os

# Configuration
API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:3100/api/v1")

class DocumentServiceClient:
    """Client for interacting with Document Service API"""

    def __init__(self, base_url: str = API_BASE_URL):
        self.base_url = base_url
        self.session = requests.Session()

    def upload_document(self, file_bytes: bytes, filename: str, org_id: str = "default", doc_name: str = None) -> Dict[str, Any]:
        """Upload a document to the service"""
        files = {"file": (filename, file_bytes, "application/pdf")}
        data = {"org_id": org_id}
        if doc_name:
            data["doc_name"] = doc_name

        response = self.session.post(f"{self.base_url}/documents/upload", files=files, data=data)
        return response.json()

    def chat_message(self, message: str, session_id: str = "streamlit_session", org_id: str = "default") -> Dict[str, Any]:
        """Send a chat message and get AI response"""
        payload = {
            "message": message,
            "session_id": session_id,
            "org_id": org_id
        }
        response = self.session.post(f"{self.base_url}/chat/", json=payload)
        return response.json()

    def get_conversation_history(self, session_id: str = "streamlit_session") -> Dict[str, Any]:
        """Get conversation history for a session"""
        response = self.session.get(f"{self.base_url}/chat/history/{session_id}")
        return response.json()

    def clear_conversation(self, session_id: str = "streamlit_session") -> Dict[str, Any]:
        """Clear conversation history"""
        response = self.session.delete(f"{self.base_url}/chat/history/{session_id}")
        return response.json()

    def search_documents(self, query: str, org_id: str = "default", limit: int = 5) -> Dict[str, Any]:
        """Search documents directly"""
        payload = {
            "query": query,
            "org_id": org_id,
            "limit": limit
        }
        response = self.session.post(f"{self.base_url}/search/", json=payload)
        return response.json()

    def health_check(self) -> bool:
        """Check if the API is accessible"""
        try:
            response = self.session.get(f"{self.base_url.replace('/api/v1', '')}/health")
            return response.status_code == 200
        except:
            return False

def simulate_streaming_response(text: str) -> Generator[str, None, None]:
    """Simulate streaming response by yielding text word by word"""
    words = text.split()
    current_text = ""

    for word in words:
        current_text += word + " "
        yield current_text
        time.sleep(0.02)  # Faster typing speed

def main():
    """Main Streamlit application"""

    # Page configuration
    st.set_page_config(
        page_title="Document Chat Assistant",
        page_icon="📄",
        layout="wide"
    )

    # Initialize API client
    client = DocumentServiceClient()

    # Session state initialization
    if "session_id" not in st.session_state:
        st.session_state.session_id = f"streamlit_{int(time.time())}"

    if "messages" not in st.session_state:
        st.session_state.messages = []

    if "api_connected" not in st.session_state:
        st.session_state.api_connected = False

    # Header
    st.title("📄 Document Chat Assistant")
    st.markdown("Upload documents and chat with AI assistant that can search through your documents")

    # Sidebar
    with st.sidebar:
        st.header("🔧 Controls")

        # API Status
        with st.container():
            if st.button("🔄 Check API Status"):
                with st.spinner("Checking API connection..."):
                    st.session_state.api_connected = client.health_check()

            if st.session_state.api_connected:
                st.success("✅ API Connected")
            else:
                st.error("❌ API Disconnected")
                st.write("Make sure the Document Service API is running on http://localhost:3100")

        st.divider()

        # Document Upload
        st.subheader("📁 Upload Document")
        uploaded_file = st.file_uploader(
            "Choose a PDF file",
            type=['pdf'],
            help="Upload a PDF document to chat with"
        )

        if uploaded_file:
            doc_name = st.text_input(
                "Document name (optional)",
                value=uploaded_file.name.replace('.pdf', ''),
                help="Unique name for this document"
            )

            if st.button("📤 Upload Document"):
                if st.session_state.api_connected:
                    with st.spinner("Uploading and processing document..."):
                        try:
                            result = client.upload_document(
                                file_bytes=uploaded_file.getvalue(),
                                filename=uploaded_file.name,
                                doc_name=doc_name
                            )
                            st.success(f"✅ Document '{doc_name}' uploaded successfully!")
                            st.json(result)
                        except Exception as e:
                            st.error(f"❌ Upload failed: {str(e)}")
                else:
                    st.error("❌ API not connected")

        st.divider()

        # Session Management
        st.subheader("💬 Chat Session")
        st.write(f"Session ID: `{st.session_state.session_id}`")

        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔄 New Session"):
                st.session_state.session_id = f"streamlit_{int(time.time())}"
                st.session_state.messages = []
                st.rerun()

        with col2:
            if st.button("🗑️ Clear History"):
                if st.session_state.api_connected:
                    client.clear_conversation(st.session_state.session_id)
                st.session_state.messages = []
                st.rerun()

        # Load conversation history
        if st.button("📜 Load History"):
            if st.session_state.api_connected:
                try:
                    history = client.get_conversation_history(st.session_state.session_id)
                    if history.get("messages"):
                        st.session_state.messages = []
                        for msg in history["messages"]:
                            st.session_state.messages.append({
                                "role": msg["role"],
                                "content": msg["content"]
                            })
                        st.success(f"✅ Loaded {len(history['messages'])} messages")
                        st.rerun()
                    else:
                        st.info("No conversation history found")
                except Exception as e:
                    st.error(f"Failed to load history: {str(e)}")

        st.divider()

        # Quick Actions
        st.subheader("⚡ Quick Actions")
        if st.button("🔍 Test Document Search"):
            if st.session_state.api_connected:
                with st.spinner("Searching documents..."):
                    try:
                        results = client.search_documents("admission requirements", limit=3)
                        st.json(results)
                    except Exception as e:
                        st.error(f"Search failed: {str(e)}")

    # Main chat interface
    st.header("💬 Chat with Your Documents")

    # Display chat messages
    if st.session_state.messages:
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
    else:
        st.info("👋 Start chatting! Ask questions about your uploaded documents or anything else.")

    # Chat input
    if prompt := st.chat_input("Ask me anything about your documents..."):
        if not st.session_state.api_connected:
            st.error("❌ Please check API connection first")
            return

        # Add user message to chat
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        # Get AI response
        with st.chat_message("assistant"):
            thinking_placeholder = st.empty()
            thinking_placeholder.markdown("🤔 Thinking...")

            try:
                # Get response from API
                response = client.chat_message(
                    message=prompt,
                    session_id=st.session_state.session_id
                )

                thinking_placeholder.empty()

                if response.get("error"):
                    st.error(f"❌ Error: {response.get('response', 'Unknown error')}")
                    return

                # Get the AI response
                ai_response = response.get("response", "No response received")

                # Truncate very long responses to prevent repetitive content
                if len(ai_response) > 2000:
                    ai_response = ai_response[:2000] + "\n\n[Response truncated for clarity]"

                # Display response directly (no streaming to avoid repetitive text)
                st.markdown(ai_response)
                full_response = ai_response

                # Add assistant response to chat
                st.session_state.messages.append({"role": "assistant", "content": full_response})

            except requests.exceptions.ConnectionError:
                thinking_placeholder.empty()
                st.error("❌ Cannot connect to Document Service API. Make sure it's running on http://localhost:3100")
            except Exception as e:
                thinking_placeholder.empty()
                st.error(f"❌ Error: {str(e)}")

    # Footer
    st.divider()
    with st.container():
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Session ID", st.session_state.session_id[-8:])
        with col2:
            st.metric("Messages", len(st.session_state.messages))
        with col3:
            status = "🟢 Connected" if st.session_state.api_connected else "🔴 Disconnected"
            st.metric("API Status", status)

if __name__ == "__main__":
    main()

# FEATURES DEMONSTRATED:
#
# 1. DOCUMENT UPLOAD: Upload PDFs directly through Streamlit interface
# 2. CHAT INTERFACE: Clean chat UI with streaming responses
# 3. SESSION MANAGEMENT: Handle multiple chat sessions
# 4. API INTEGRATION: Full integration with Document Service API
# 5. ERROR HANDLING: Graceful handling of API errors
# 6. REAL-TIME STATUS: Live API connection status
# 7. CONVERSATION HISTORY: Load and clear chat history
# 8. DOCUMENT SEARCH: Direct document search functionality
# 9. RESPONSIVE UI: Sidebar controls and main chat area
# 10. STREAMING SIMULATION: Typewriter effect for responses
#
# USAGE:
# 1. Start the Document Service API: uvicorn src.main:app --reload
# 2. Run Streamlit app: streamlit run streamlit_app.py
# 3. Upload documents and start chatting!