#!/usr/bin/env python3
"""
Startup script for Document Service with Streamlit frontend
Runs both the FastAPI backend and Streamlit frontend
"""

import subprocess
import sys
import time
import webbrowser
from pathlib import Path

def run_api_server():
    """Start the FastAPI server"""
    print("🚀 Starting Document Service API...")
    return subprocess.Popen([
        sys.executable, "-m", "uvicorn",
        "src.main:app",
        "--reload",
        "--host", "0.0.0.0",
        "--port", "3100"
    ])

def run_streamlit_app():
    """Start the Streamlit app"""
    print("🎨 Starting Streamlit frontend...")
    return subprocess.Popen([
        sys.executable, "-m", "streamlit",
        "run",
        "frontend/streamlit_app.py",
        "--server.port", "8501"
    ])

def main():
    """Main function to start both services"""
    print("=" * 60)
    print("🏗️  DOCUMENT SERVICE LAUNCHER")
    print("=" * 60)

    # Start API server
    api_process = run_api_server()
    print("✅ FastAPI server starting on http://localhost:3100")

    # Wait a moment for API to start
    print("⏳ Waiting for API to initialize...")
    time.sleep(3)

    # Start Streamlit app
    streamlit_process = run_streamlit_app()
    print("✅ Streamlit app starting on http://localhost:8501")

    print("\n" + "=" * 60)
    print("🎉 SERVICES RUNNING:")
    print("📡 API Documentation: http://localhost:3100/docs")
    print("🎨 Streamlit App: http://localhost:8501")
    print("=" * 60)
    print("\n💡 TIP: Upload a PDF document first, then start chatting!")
    print("🛑 Press Ctrl+C to stop both services")

    try:
        # Wait for both processes
        api_process.wait()
        streamlit_process.wait()
    except KeyboardInterrupt:
        print("\n🛑 Shutting down services...")
        api_process.terminate()
        streamlit_process.terminate()

        # Wait for graceful shutdown
        try:
            api_process.wait(timeout=5)
            streamlit_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            api_process.kill()
            streamlit_process.kill()

        print("✅ Services stopped")

if __name__ == "__main__":
    main()