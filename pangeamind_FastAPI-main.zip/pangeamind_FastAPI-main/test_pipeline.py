#!/usr/bin/env python3
"""Test script for the complete RAG pipeline."""

import asyncio
import os
from src.services.rag_pipeline_service import RAGPipelineService
from src.models.document import DocumentUploadRequest, DocumentSearchRequest


async def test_complete_pipeline():
    """Test the complete document processing and search pipeline."""

    # Initialize the pipeline
    print("🚀 Initializing RAG Pipeline...")
    pipeline = RAGPipelineService()
    await pipeline.initialize()
    print("✅ Pipeline initialized\n")

    # Test document parameters
    test_file = "data_files/vector-search-international-journal-of-computer-trends-and-technology-ijctt-gaurav-prabhakar.pdf"
    test_org_id = "test-org-123"
    test_doc_url = "test-document.pdf"

    # Check if test file exists
    if not os.path.exists(test_file):
        print(f"❌ Test file not found: {test_file}")
        print("Please ensure you have a test PDF file in the data_files directory")
        return

    try:
        # Step 1: Process the document
        print("📄 Testing Document Processing...")
        print(f"   File: {test_file}")
        print(f"   Org ID: {test_org_id}")
        print(f"   Doc URL: {test_doc_url}\n")

        document = await pipeline.process_document(
            file_path=test_file,
            org_id=test_org_id,
            doc_url=test_doc_url,
            metadata={"test": True, "source": "test_script"}
        )

        print(f"✅ Document processed successfully!")
        print(f"   Document URL: {document.doc_url}")
        print(f"   Organization: {document.org_id}\n")

        # Step 2: Test search functionality
        print("🔍 Testing Search Functionality...")

        # Test queries
        test_queries = [
            "What is vector search?",
            "How does indexing work?",
            "database performance"
        ]

        for query in test_queries:
            print(f"\n   Query: '{query}'")

            # Search without filters
            results = await pipeline.search(
                query=query,
                limit=3
            )

            print(f"   Found {results.total_results} results (no filter)")
            if results.results:
                for i, result in enumerate(results.results[:2], 1):
                    print(f"     Result {i}: Score={result['score']:.3f}")
                    preview = result['text'][:100] + "..." if len(result['text']) > 100 else result['text']
                    print(f"     Preview: {preview}")

            # Search with org_id filter
            filtered_results = await pipeline.search(
                query=query,
                org_id=test_org_id,
                limit=3
            )

            print(f"   Found {filtered_results.total_results} results (with org_id filter)")

        # Step 3: Test search with both org_id and doc_url filters
        print("\n🎯 Testing Filtered Search (org_id + doc_url)...")
        specific_results = await pipeline.search(
            query="vector search",
            org_id=test_org_id,
            doc_url=test_doc_url,
            limit=5
        )

        print(f"   Found {specific_results.total_results} results for specific document")

        # Step 4: Test document deletion
        print("\n🗑️  Testing Document Deletion...")
        await pipeline.delete_document(test_org_id, test_doc_url)
        print("✅ Document deleted successfully")

        # Verify deletion by searching again
        post_delete_results = await pipeline.search(
            query="vector search",
            org_id=test_org_id,
            doc_url=test_doc_url,
            limit=5
        )

        if post_delete_results.total_results == 0:
            print("✅ Verified: Document no longer in database")
        else:
            print("⚠️  Warning: Document may not have been fully deleted")

        print("\n🎉 All tests completed successfully!")

    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        raise


async def test_api_models():
    """Test the API request/response models."""
    print("\n📋 Testing API Models...")

    # Test DocumentUploadRequest
    upload_request = DocumentUploadRequest(
        file_path="test.pdf",
        org_id="org-123",
        doc_url="https://example.com/test.pdf",
        title="Test Document",
        metadata={"category": "test"}
    )
    print(f"✅ DocumentUploadRequest created: {upload_request.org_id}")

    # Test DocumentSearchRequest
    search_request = DocumentSearchRequest(
        query="test query",
        org_id="org-123",
        limit=10
    )
    print(f"✅ DocumentSearchRequest created: {search_request.query}")


async def main():
    """Run all tests."""
    print("=" * 60)
    print("RAG PIPELINE TEST SUITE")
    print("=" * 60 + "\n")

    # Test the complete pipeline
    await test_complete_pipeline()

    # Test the models
    await test_api_models()

    print("\n" + "=" * 60)
    print("✅ ALL TESTS COMPLETED")
    print("=" * 60)


if __name__ == "__main__":
    # Run the async tests
    asyncio.run(main())