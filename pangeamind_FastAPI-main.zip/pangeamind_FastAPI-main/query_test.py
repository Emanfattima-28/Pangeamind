#!/usr/bin/env python3
"""Test querying the vector database with specific questions."""

import asyncio
import sys
import argparse
from pathlib import Path

# Add src to path so internal imports (e.g. from services...) work
sys.path.append(str(Path(__file__).parent / "src"))

from services.rag_pipeline_service import RAGPipelineService

async def ingest_and_query(input_file: str, query_text: str = None):
    """Ingest a document and run various queries."""

    # Initialize the pipeline
    print("🚀 Initializing RAG Pipeline...")
    pipeline = RAGPipelineService()
    await pipeline.initialize()

    # Ingest the document
    test_file = input_file
    test_org_id = "test-research-org"
    test_doc_name = Path(test_file).name

    print(f"\n📄 Ingesting document: {test_file}")
    document = await pipeline.process_document(
        file_path=test_file,
        org_id=test_org_id,
        doc_name=test_doc_name,
        metadata={"type": "research_paper", "topic": "testing"}
    )
    print(f"✅ Document ingested successfully (ID: {document.doc_id})!\n")

    # If a specific query is provided, use it. Otherwise use defaults.
    if query_text:
        queries = [query_text]
    else:
        # Test various queries
        queries = [
            "What is vector search and how does it work?",
            "What are the main applications of vector search?",
            "What are the advantages of vector search over traditional search?",
            "What similarity metrics are used in vector search?",
        ]

    print("=" * 60)
    print("QUERYING VECTOR DATABASE")
    print("=" * 60)

    for i, query in enumerate(queries, 1):
        print(f"\n🔍 Query {i}: {query}")
        print("-" * 40)

        # Search with filters
        results = await pipeline.search(
            query=query,
            org_id=test_org_id,
            doc_name=test_doc_name,
            limit=2
        )

        if results.results:
            for j, result in enumerate(results.results, 1):
                print(f"\n  📊 Result {j} (Score: {result['score']:.3f})")

                # Show the full chunk text
                text = result['text']
                # Limit to 300 characters for readability
                if len(text) > 300:
                    text = text[:300] + "..."

                print(f"  📝 Content: {text}")

                # Show metadata
                metadata = result['metadata']
                print(f"  📌 Chunk Index: {metadata.get('chunk_index', 'N/A')}")
        else:
            print("  ❌ No results found")

    # Clean up
    print("\n🗑️  Cleaning up...")
    await pipeline.delete_document(test_org_id, test_doc_name)
    print("✅ Test document deleted from vector store")

    print("\n" + "=" * 60)
    print("✅ QUERY TESTING COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test RAG Pipeline with a document")
    parser.add_argument("--file", type=str, required=True, help="Path to the PDF file")
    parser.add_argument("--query", type=str, help="Specific query to run")
    
    args = parser.parse_args()
    
    if not Path(args.file).exists():
        print(f"❌ Error: File not found: {args.file}")
        sys.exit(1)
        
    asyncio.run(ingest_and_query(args.file, args.query))