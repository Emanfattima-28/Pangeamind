#!/usr/bin/env python3
"""
Test script to verify Streamlit app functionality using Playwright
"""

import asyncio
import time
from playwright.async_api import async_playwright
import os

async def test_streamlit_app():
    """Test the Streamlit application"""
    async with async_playwright() as p:
        # Launch browser
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        print("🚀 Testing Streamlit Document Chat Assistant...")

        try:
            # Navigate to Streamlit app
            await page.goto("http://localhost:8501")
            await page.wait_for_load_state('networkidle')

            # Wait for app to load
            await page.wait_for_selector('h1:has-text("Document Chat Assistant")', timeout=10000)
            print("✅ Streamlit app loaded successfully")

            # Take initial screenshot
            await page.screenshot(path="screenshot_1_initial.png", full_page=True)
            print("📸 Initial screenshot taken")

            # Check API status button
            try:
                api_button = page.locator('button:has-text("Check API Status")')
                if await api_button.is_visible():
                    await api_button.click()
                    await page.wait_for_timeout(2000)  # Wait for API check
                    print("✅ API status checked")

                    # Take screenshot after API check
                    await page.screenshot(path="screenshot_2_api_check.png", full_page=True)
            except Exception as e:
                print(f"⚠️ API check failed: {e}")

            # Look for chat input
            chat_input = page.locator('div[data-testid="stChatInput"] textarea')
            if await chat_input.is_visible():
                print("✅ Chat input found")

                # Test chat functionality
                test_message = "What is this document about?"
                await chat_input.fill(test_message)
                await page.keyboard.press('Enter')

                print(f"📝 Sent message: '{test_message}'")

                # Wait for response
                await page.wait_for_timeout(8000)  # Wait for AI response

                # Take screenshot after chat
                await page.screenshot(path="screenshot_3_chat_response.png", full_page=True)
                print("📸 Chat response screenshot taken")

                # Check if there's a response in the chat
                chat_messages = await page.locator('div[data-testid="stChatMessage"]').count()
                print(f"💬 Found {chat_messages} chat messages")

                if chat_messages >= 2:  # User message + bot response
                    print("✅ Chat functionality working!")

                    # Test another question
                    test_message2 = "What are the admission requirements?"
                    await chat_input.fill(test_message2)
                    await page.keyboard.press('Enter')

                    print(f"📝 Sent second message: '{test_message2}'")
                    await page.wait_for_timeout(8000)

                    # Final screenshot
                    await page.screenshot(path="screenshot_4_final.png", full_page=True)
                    print("📸 Final screenshot taken")

                else:
                    print("❌ No chat response detected")
            else:
                print("❌ Chat input not found")

        except Exception as e:
            print(f"❌ Error during testing: {e}")
            await page.screenshot(path="screenshot_error.png", full_page=True)

        finally:
            await browser.close()
            print("🏁 Browser closed")

async def main():
    """Main test function"""
    print("🧪 Starting Playwright test of Streamlit app...")

    # Wait a moment for services to be ready
    print("⏳ Waiting for services to be ready...")
    time.sleep(3)

    await test_streamlit_app()

    print("\n📊 Test Results:")
    print("- screenshot_1_initial.png: Initial app load")
    print("- screenshot_2_api_check.png: After API status check")
    print("- screenshot_3_chat_response.png: After first chat message")
    print("- screenshot_4_final.png: After second chat message")

if __name__ == "__main__":
    asyncio.run(main())