import pytest
import sys
import os
from unittest.mock import MagicMock, patch, AsyncMock
from pathlib import Path

# Add src to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from services.chunking_service import ChunkingService, WordBasedChunking, SentenceBasedChunking
from services.document_service import DocumentServiceFactory, LlamaDocumentService
from services.embedding_service import EmbeddingService
from services.vector_store_service import VectorStoreService
from services.rag_pipeline_service import RAGPipelineService
from models.document import Document, DocumentUploadRequest, DocumentSearchRequest
from config.settings import settings

# ---------------------------------------------------------
# SETTINGS TESTS (2)
# ---------------------------------------------------------

def test_config_loading():
    """Test that settings are loaded and have expected types."""
    assert isinstance(settings.chunk_size, int)
    assert isinstance(settings.chunk_overlap, int)
    assert settings.chunk_size > settings.chunk_overlap

def test_qdrant_url_format():
    """Test that Qdrant URL is properly formatted."""
    assert settings.qdrant_url.startswith("http")
    assert ":6333" in settings.qdrant_url

# ---------------------------------------------------------
# CHUNKING SERVICE TESTS (4)
# ---------------------------------------------------------

def test_word_chunking_basic():
    """Test basic word-based chunking."""
    service = ChunkingService(WordBasedChunking())
    text = "one two three four five"
    chunks = service.chunk_text(text, chunk_size=2, overlap=0)
    assert len(chunks) == 3
    assert chunks[0]["text"] == "one two"
    assert chunks[1]["text"] == "three four"
    assert chunks[2]["text"] == "five"

def test_word_chunking_overlap():
    """Test word-based chunking with overlap."""
    service = ChunkingService(WordBasedChunking())
    text = "one two three four"
    chunks = service.chunk_text(text, chunk_size=2, overlap=1)
    assert len(chunks) == 3
    assert chunks[0]["text"] == "one two"
    assert chunks[1]["text"] == "two three"
    assert chunks[2]["text"] == "three four"

def test_sentence_chunking_basic():
    """Test sentence-based chunking."""
    service = ChunkingService(SentenceBasedChunking())
    text = "Sentence one. Sentence two! Sentence three?"
    chunks = service.chunk_text(text, chunk_size=10, overlap=0)
    assert len(chunks) == 1
    assert "Sentence one." in chunks[0]["text"]
    assert "Sentence three?" in chunks[0]["text"]

def test_chunking_metadata():
    """Test that chunks contain required metadata fields."""
    service = ChunkingService()
    text = "This is a test of chunking metadata."
    chunks = service.chunk_text(text, chunk_size=5, overlap=0)
    for i, chunk in enumerate(chunks):
        assert "text" in chunk
        assert "chunk_index" in chunk
        assert "word_count" in chunk
        assert chunk["chunk_index"] == i

# ---------------------------------------------------------
# DOCUMENT SERVICE TESTS (3)
# ---------------------------------------------------------

def test_factory_creation():
    """Test the DocumentServiceFactory."""
    parser = DocumentServiceFactory.create_parser("llama")
    assert isinstance(parser, LlamaDocumentService)
    
    with pytest.raises(ValueError):
        DocumentServiceFactory.create_parser("unknown_type")

@pytest.mark.asyncio
async def test_llama_service_parse_success():
    """Test LlamaDocumentService with mocked LlamaParse."""
    with patch("services.document_service.LlamaParse") as mock_parse:
        mock_instance = mock_parse.return_value
        mock_instance.aload_data = AsyncMock(return_value=[MagicMock(text="Extracted text content")])
        
        service = LlamaDocumentService()
        # Mock os.path.exists to avoid real file checks
        with patch("os.path.exists", return_value=True):
            text = await service.parse("fake_path.pdf")
            assert "Extracted text content" in text

@pytest.mark.asyncio
async def test_pypdf_fallback():
    """Test the pypdf fallback when LlamaParse fails."""
    with patch("services.document_service.LlamaParse") as mock_parse:
        mock_instance = mock_parse.return_value
        mock_instance.aload_data = AsyncMock(side_effect=Exception("insufficient_quota"))
        
        with patch("pypdf.PdfReader") as mock_pdf:
            mock_reader = mock_pdf.return_value
            mock_page = MagicMock()
            mock_page.extract_text.return_value = "Fallback text content"
            mock_reader.pages = [mock_page]
            
            service = LlamaDocumentService()
            with patch("os.path.exists", return_value=True):
                text = await service.parse("fake_path.pdf")
                assert "Fallback text content" in text

# ---------------------------------------------------------
# EMBEDDING SERVICE TESTS (2)
# ---------------------------------------------------------

@pytest.mark.asyncio
async def test_embedding_generation():
    """Test OpenAI embedding generation with mock."""
    with patch("services.embedding_service.OpenAI") as mock_openai:
        mock_client = mock_openai.return_value
        mock_response = MagicMock()
        mock_data = MagicMock()
        mock_data.embedding = [0.1, 0.2, 0.3]
        mock_response.data = [mock_data]
        mock_client.embeddings.create.return_value = mock_response
        
        service = EmbeddingService()
        embeddings = await service.create_embeddings(["test text"])
        assert len(embeddings) == 1
        assert embeddings[0] == [0.1, 0.2, 0.3]

def test_embedding_dimensions():
    """Test that dimension helper returns values from settings or map."""
    service = EmbeddingService(model="text-embedding-3-small")
    assert service.get_embedding_dimension() == 1536
    
    service.model = "unknown"
    assert service.get_embedding_dimension() == settings.embedding_dimensions

# ---------------------------------------------------------
# VECTOR STORE TESTS (4)
# ---------------------------------------------------------

@pytest.mark.asyncio
async def test_vector_store_initialization():
    """Test Qdrant collection creation mock."""
    with patch("services.vector_store_service.QdrantClient") as mock_qdrant:
        mock_client = mock_qdrant.return_value
        mock_coll_info = MagicMock()
        mock_coll_info.collections = []
        mock_client.get_collections.return_value = mock_coll_info
        
        service = VectorStoreService(collection_name="test_collection")
        await service.create_collection()
        
        mock_client.create_collection.assert_called_once()
        assert "test_collection" in str(mock_client.create_collection.call_args)

@pytest.mark.asyncio
async def test_vector_store_upsert():
    """Test upserting vectors to Qdrant with mock."""
    with patch("services.vector_store_service.QdrantClient") as mock_qdrant:
        mock_client = mock_qdrant.return_value
        service = VectorStoreService()
        
        chunks = [{"text": "chunk1", "chunk_index": 0}]
        embeddings = [[0.1, 0.1]]
        
        ids = await service.store_embeddings(chunks, embeddings, "org1", "doc1", "name1")
        assert len(ids) == 1
        mock_client.upsert.assert_called_once()

@pytest.mark.asyncio
async def test_vector_store_search():
    """Test searching vectors in Qdrant with mock."""
    with patch("services.vector_store_service.QdrantClient") as mock_qdrant:
        mock_client = mock_qdrant.return_value
        mock_result = MagicMock()
        mock_result.id = "uid-1"
        mock_result.score = 0.95
        mock_result.payload = {"chunk_text": "found it", "org_id": "org1"}
        mock_client.search.return_value = [mock_result]
        
        service = VectorStoreService()
        results = await service.search([0.1, 0.1], org_id="org1")
        
        assert len(results) == 1
        assert results[0]["text"] == "found it"
        assert results[0]["score"] == 0.95

@pytest.mark.asyncio
async def test_vector_store_delete():
    """Test deleting documents in Qdrant with mock."""
    with patch("services.vector_store_service.QdrantClient") as mock_qdrant:
        mock_client = mock_qdrant.return_value
        service = VectorStoreService()
        
        await service.delete_document("org1", "doc_name")
        mock_client.delete.assert_called_once()

# ---------------------------------------------------------
# PIPELINE SERVICE TESTS (5)
# ---------------------------------------------------------

@pytest.mark.asyncio
async def test_pipeline_initialization():
    """Test RAG pipeline initialization."""
    pipeline = RAGPipelineService()
    # Mocking self.vector_store.create_collection
    pipeline.vector_store = MagicMock()
    pipeline.vector_store.create_collection = AsyncMock()
    
    await pipeline.initialize()
    pipeline.vector_store.create_collection.assert_called_once()

@pytest.mark.asyncio
async def test_pipeline_process_document():
    """Test full document processing orchestrator."""
    pipeline = RAGPipelineService()
    
    # Mock all internal service calls
    pipeline.document_parser.parse = AsyncMock(return_value="long text")
    pipeline.chunking_service.chunk_text = MagicMock(return_value=[{"text": "chunk1", "chunk_index": 0}])
    pipeline.embedding_service.create_embeddings = AsyncMock(return_value=[[0.1, 0.1]])
    pipeline.vector_store.store_embeddings = AsyncMock(return_value=["point-id-1"])
    
    doc = await pipeline.process_document("path.pdf", "org1", "doc_name")
    
    assert doc.doc_name == "doc_name"
    assert doc.org_id == "org1"
    pipeline.document_parser.parse.assert_called_once()
    pipeline.vector_store.store_embeddings.assert_called_once()

@pytest.mark.asyncio
async def test_pipeline_search_orchestration():
    """Test search orchestration."""
    pipeline = RAGPipelineService()
    pipeline.embedding_service.create_single_embedding = AsyncMock(return_value=[0.1, 0.1])
    pipeline.vector_store.search = AsyncMock(return_value=[{"text": "res", "score": 0.9}])
    
    response = await pipeline.search("query", org_id="org1")
    
    assert response.query == "query"
    assert len(response.results) == 1
    assert response.total_results == 1

@pytest.mark.asyncio
async def test_pipeline_delete_orchestration():
    """Test delete orchestration."""
    pipeline = RAGPipelineService()
    pipeline.vector_store.delete_document = AsyncMock(return_value=1)
    
    success = await pipeline.delete_document("org1", "doc1")
    assert success is True
    pipeline.vector_store.delete_document.assert_called_once_with("org1", "doc1")

@pytest.mark.asyncio
async def test_pipeline_models():
    """Test that models correctly store data."""
    request = DocumentUploadRequest(
        file_path="test.pdf",
        org_id="org1",
        doc_name="doc1",
        metadata={"key": "val"}
    )
    assert request.org_id == "org1"
    assert request.metadata["key"] == "val"
    
    search = DocumentSearchRequest(query="find me", limit=5)
    assert search.query == "find me"
    assert search.limit == 5

if __name__ == "__main__":
    # If run directly instead of via pytest
    pytest.main([__file__, "-v"])